import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @Merriam 
 * (NOT NEEDED ANYMORE)
 * GUI to display and get user input for company filters.
 */
public class CompanyFilterGUI extends JFrame {
    private JTextField rankingField;
    private JTextField locationField;
    private CompanyFilterApp companyFilterApp;

    public CompanyFilterGUI(CompanyFilterApp companyFilterApp) {
        this.companyFilterApp = companyFilterApp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Company Filters");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        panel.add(new JLabel("Minimum and Maximum Ranking (e.g., 20-40):"));
        rankingField = new JTextField();
        panel.add(rankingField);

        panel.add(new JLabel("Location:"));
        locationField = new JTextField();
        panel.add(locationField);

        JButton applyButton = new JButton("Apply Filters");
        applyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                applyFilters();
            }
        });
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(applyButton);

        getContentPane().add(panel);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void applyFilters() {
        String rankingFilter = rankingField.getText();
        String locationFilter = locationField.getText();

        // Pass the filters to the main application
        companyFilterApp.applyFilters(rankingFilter, locationFilter);

        // Close the filter GUI
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // Create an instance of CompanyFilterApp and pass it to the GUI
                new CompanyFilterGUI(new CompanyFilterApp());
            }
        });
    }
}
