import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/*
 * @Merriam
 * 
 * This page will display the Review page (referenced from image )
 */


public class ReviewPageGUI {
    private static final String FILE_PATH = "reviews.txt";

    private List<String> reviews;
    private JFrame frame;
    private JLabel reviewLabel;
    private int starRating;

    public ReviewPageGUI() {
        reviews = loadReviews();
        initializeGUI();
    }

    private void initializeGUI() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }

        frame = new JFrame("Review Page");
        frame.setSize(1500, 1000);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel for the company overview
        JPanel companyOverviewPanel = new JPanel();
        companyOverviewPanel.setLayout(new BorderLayout());
        companyOverviewPanel.setPreferredSize(new Dimension(frame.getWidth(), frame.getHeight() / 4));
        companyOverviewPanel.setBackground(Color.decode("#336699")); // Background color

        // Add company overview text
        JTextArea companyOverviewText = new JTextArea();
        companyOverviewText.setEditable(false);
        companyOverviewText.setFont(new Font("Charter", Font.PLAIN, 18));
        companyOverviewText.setForeground(Color.BLACK); // Text color
        companyOverviewText.setLineWrap(true);
        companyOverviewText.setWrapStyleWord(true);
        companyOverviewText.setText("Welcome to PQR Limited! We are dedicated to providing high-quality products and excellent customer service. We prioritize the quality of our products!");

        
        ImageIcon companyImage = new ImageIcon("path/to/your/istockphoto-479842074-612x612.jpg");
        JLabel companyImageLabel = new JLabel(companyImage);

        // Add components to the company overview panel
        companyOverviewPanel.add(companyOverviewText, BorderLayout.CENTER);
        companyOverviewPanel.add(companyImageLabel, BorderLayout.EAST);

        // Add the company overview panel to the frame
        frame.getContentPane().add(companyOverviewPanel, BorderLayout.NORTH);

        // Rest of the code...
        reviewLabel = new JLabel();
        reviewLabel.setVerticalAlignment(JLabel.TOP);
        reviewLabel.setFont(new Font("Charter", Font.PLAIN, 14));
        reviewLabel.setForeground(Color.decode("#473e1e")); // Text color
        updateReviewLabel();

        JScrollPane scrollPane = new JScrollPane(reviewLabel);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        JTextField newReviewTextField = new JTextField();
        newReviewTextField.setFont(new Font("Charter", Font.PLAIN, 14));

        JPanel starPanel = createStarPanel();

        JButton submitButton = new JButton("Submit Review");
        submitButton.setFont(new Font("Charter", Font.BOLD, 14));
        submitButton.setBackground(Color.decode("#a5ab90")); // Background color
        submitButton.setForeground(Color.BLACK); // Text color
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newReview = newReviewTextField.getText();
                if (!newReview.isEmpty()) {
                    String username = generateUsername();
                    reviews.add("@" + username + ": " + newReview + " Rating given: " + starRating + " stars");
                    saveReviews(reviews);
                    updateReviewLabel();
                    newReviewTextField.setText("");
                    resetStarRating();
                }
            }
        });

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BorderLayout());
        inputPanel.add(newReviewTextField, BorderLayout.CENTER);
        inputPanel.add(starPanel, BorderLayout.WEST);
        inputPanel.add(submitButton, BorderLayout.EAST);
        inputPanel.setBackground(Color.decode("#808c5b")); // Panel background color

        frame.getContentPane().add(inputPanel, BorderLayout.SOUTH);

        frame.getContentPane().setBackground(Color.decode("#99a683")); // Main background color
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private String generateUsername() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        return "user" + dateFormat.format(new Date());
    }

    private void resetStarRating() {
        starRating = 0;
    }

    private JPanel createStarPanel() {
        JPanel starPanel = new JPanel();
        starPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
        starPanel.setBackground(Color.decode("#808c5b"));

        for (int i = 1; i <= 5; i++) {
            JLabel starLabel = new JLabel("★");
            starLabel.setFont(new Font("Charter", Font.BOLD, 24));
            starLabel.setForeground(Color.decode("#bfae13")); // Star border color

            int finalI = i; // to make it effectively final for the inner class
            starLabel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    setStarRating(finalI);
                }
            });

            starPanel.add(starLabel);
        }

        return starPanel;
    }

    private void setStarRating(int rating) {
        starRating = rating;
        updateStarColors(rating);
    }

    private void updateStarColors(int selectedRating) {
        for (Component component : ((JPanel) frame.getContentPane().getComponent(1)).getComponents()) {
            if (component instanceof JLabel) {
                JLabel starLabel = (JLabel) component;
                int starNumber = Integer.parseInt(starLabel.getText().replaceAll("[^\\d]", ""));
                if (starNumber <= selectedRating) {
                    starLabel.setForeground(Color.decode("#ebda42")); // Selected star color
                } else {
                    starLabel.setForeground(Color.decode("#bf8c24")); // Star border color
                }
            }
        }
    }

    private void updateReviewLabel() {
        StringBuilder displayText = new StringBuilder("<html><font color='#dbd9c5'>PQR Limited Reviews:</font><br>");
        for (String review : reviews) {
            displayText.append("<font color='#4C6849'>•</font> ").append(review).append("<br>");
        }
        reviewLabel.setText(displayText.append("</html>").toString());
    }

    private List<String> loadReviews() {
        List<String> reviews = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                reviews.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading reviews from file: " + e.getMessage());
        }

        return reviews;
    }

    private void saveReviews(List<String> reviews) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String review : reviews) {
                writer.write(review);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing reviews to file: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ReviewPageGUI();
            }
        });
    }
}