/*
 * @Merriam 
 * /**
 * Main application class responsible for managing the review functionality.
 */

public class ReviewPageApp {

    public static void main(String[] args) {
                // Create an instance of ReviewManager and run the review application
        ReviewManager reviewManager = new ReviewManager();
        reviewManager.runReviewApp();
    }
}


