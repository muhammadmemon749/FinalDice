import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * @Merriam
 * Saves all th ereviews to a file.
 */
public class ReviewSaver {
    private String filePath;

    /**
     * Initializes ReviewSaver with the file path.
     *
     * @param filePath The path to the reviews file.
     */
    public ReviewSaver(String filePath) {
        this.filePath = filePath;
    }

    /**
     * Saves reviews to the file.
     *
     * @param reviews The list of reviews to be saved.
     */
    public void saveReviews(List<String> reviews) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String review : reviews) {
                writer.write(review);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing reviews to file: " + e.getMessage());
        }
    }
}

