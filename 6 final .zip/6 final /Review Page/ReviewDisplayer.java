import java.util.List;

/**
 * Displays reviews to the console.
 * @Merriam
 */
public class ReviewDisplayer {

    /**
     * Displays company reviews to the console.
     *
     * @param reviews The list of reviews to display.
     */
    public void displayCompanyReviews(List<String> reviews) {
        System.out.println("PQR Limited Reviews:");
        for (String review : reviews) {
            if (review.contains("PQR Limited")) {
                System.out.println(review);
            }
        }
    }

    /**
     * Displays a review page to the console.
     *
     * @param reviews The list of reviews to display.
     */
    public void displayReviewPage(List<String> reviews) {
        System.out.println("\n--- Review Page ---");
        displayCompanyReviews(reviews);
        System.out.println("---------------------------\n");
    }
}
