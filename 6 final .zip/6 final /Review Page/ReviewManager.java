import java.util.List;
import java.util.Scanner;

/*
 * @Merriam
 * 
/**
 * Manages the overall flow of the review application.
 */
public class ReviewManager {
    private static final String FILE_PATH = "reviews.txt";

    private ReviewLoader loader;
    private ReviewSaver saver;
    private ReviewDisplayer displayer;

    /**
     * Initializes ReviewManager 
     */
    public ReviewManager() {
        this.loader = new ReviewLoader(FILE_PATH);
        this.saver = new ReviewSaver(FILE_PATH);
        this.displayer = new ReviewDisplayer();
    }

    /**
     * Runs the review application, loading, displaying, and saves rthe reviews.
     */
    public void runReviewApp() {
        List<String> reviews = loader.loadReviews();

        displayer.displayCompanyReviews(reviews);

        System.out.println("Leave your review here! (type 'exit' to finish):");

        try (Scanner scanner = new Scanner(System.in)) {
            String newReview;
            while (true) {
                newReview = scanner.nextLine();
                if (newReview.equalsIgnoreCase("exit")) {
                    break;
                }
                reviews.add(newReview);
                saver.saveReviews(reviews);
                displayer.displayReviewPage(reviews);
            }
        }
        System.out.println("Your review has been added!");
    }
}
