import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
 * @Merriam
 * 
 * This page's function is to get fake reviews from the reviews.txt file, get a user's review, 
 * update the txt file, and display the new reviews (transferred this role to ReviewPageGUI) 
 * COde before refactoring 
 */
public class ReviewPage {
    private static final String FILE_PATH = "reviews.txt";

    public static void main(String[] args) {
        List<String> reviews = loadReviews();

        displayCompanyReviews(reviews);

        System.out.println("Leave your review here! (type 'exit' to finish):");

        try (Scanner scanner = new Scanner(System.in)) {
            String newReview;
            while (true) {
                newReview = scanner.nextLine();
                if (newReview.equalsIgnoreCase("exit")) {
                    break;
                }
                reviews.add(newReview);
                saveReviews(reviews);
                displayReviewPage(reviews);
            }
        }
        System.out.println("Your review has been added!");
    }

    private static List<String> loadReviews() {
        List<String> reviews = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                reviews.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading reviews from file: " + e.getMessage());
        }

        return reviews;
    }

    private static void displayCompanyReviews(List<String> reviews) {
        System.out.println("PQR Limited Reviews:");
        for (String review : reviews) {
            if (review.contains("PQR Limited")) {
                System.out.println(review);
            }
        }
    }

    private static void saveReviews(List<String> reviews) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String review : reviews) {
                writer.write(review);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing reviews to file: " + e.getMessage());
        }
    }
    private static void displayReviewPage(List<String> reviews) {
        System.out.println("\n--- Review Page ---");
        displayCompanyReviews(reviews);
        System.out.println("---------------------------\n");
    }
}
