package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReviewPage {

    /**
     * Creates the selected company's review page, which shows:
     * Company's name
     * Company overview
     * Existing reviews
     * Option to leave a review
     * Filter bar (by stars)
     * @author Yazan
     */
    public static void createReviewPage() {
        // Creating the frame
        JFrame frame = new JFrame("Review Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Setting the size of the page
        frame.setSize(1000, 800);
        frame.setLocationRelativeTo(null);
        // Adding some space between panels
        frame.setLayout(new BorderLayout(10, 10));
        frame.setVisible(true);

        // Creating a JPanel for the company title, overview, and go-back button
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setPreferredSize(new Dimension(100, 100));
        topPanel.setBackground(Color.lightGray);

        // Creating a JLabel that shows the company's name
        JLabel titleOfCompany = new JLabel();
        titleOfCompany.setText("Company Name Reviews Page"); // The selected company's name goes here
        titleOfCompany.setBackground(Color.lightGray);
        // Changing title font and size
        Font titleFont = new Font("Times New Roman", Font.BOLD, 40);
        titleOfCompany.setFont(titleFont);
        // Changing title position
        titleOfCompany.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleOfCompany.setAlignmentY(Component.TOP_ALIGNMENT);
        
        // Adding the title to the panel
        topPanel.add(titleOfCompany, BorderLayout.NORTH);

        // Creating a text area for the company overview
        JLabel companyOverview = new JLabel("Company Info & Rank Go Here"); // Company's overview goes here
        // Setting font and size
        Font overviewFont = new Font("Times New Roman", Font.PLAIN, 14);
        companyOverview.setFont(overviewFont);
        // Aligning
        companyOverview.setAlignmentX(Component.LEFT_ALIGNMENT);
        companyOverview.setAlignmentY(Component.CENTER_ALIGNMENT);
        // Adding the JTextArea companyOverview to the JPanel
        topPanel.add(companyOverview, BorderLayout.CENTER);

        // Creating a button to go back to the previous page
        JButton goBackButton = new JButton("Go Back");
        // Size adjustment
        goBackButton.setPreferredSize(new Dimension(90, 20));
        // Alignment
        goBackButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Adding the button to the panel
        topPanel.add(goBackButton, BorderLayout.EAST);

        // Adding a listener that does something when the user presses on a button
        // In this case: goes to the previous page (company page) when button is pressed
        goBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Calling the createCompanyPageGUI method from CompanyPage.java, which creates the page again
                CompanyPage.createCompanyPageGUI();
                // Setting this page (companyPage) to not-visible so the user automatically sees the previous page
                frame.setVisible(false);
                /*
                 * Disposing of the page: basically gets rid of the components of this page
                 * Frees up memory
                 */
                frame.dispose();
            }
        });

        // Creating a JPanel for the company's data
        JPanel resultsPanel = new JPanel();
        resultsPanel.setPreferredSize(new Dimension(100, 100));
        resultsPanel.setBackground(Color.WHITE);
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));

        // Creating JLabels that show existing reviews
        JLabel review1 = new JLabel("review text goes here");
        JLabel review2 = new JLabel("review text goes here");
        JLabel review3 = new JLabel("review text goes here");
        JLabel review4 = new JLabel("review text goes here");
        JLabel review5 = new JLabel("review text goes here");
        resultsPanel.add(review1);
        resultsPanel.add(review2);
        resultsPanel.add(review3);
        resultsPanel.add(review4);
        resultsPanel.add(review5);

        // adding the panels to the frame
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(resultsPanel, BorderLayout.CENTER); 
    }
}
