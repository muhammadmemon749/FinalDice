package GUI;

import javax.swing.JPanel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CompanyPage {
    /**
     * Creates the selected company's page, which shows:
     * Company's name
     * Company overview
     * Gender wage disparity
     * Employees male to female ratio
     * Reported incidents
     * Diversity of the employees
     * Company score (calculated from the above data)
     * @author Yazan
     */
    public static void createCompanyPageGUI() {

        // Creating the frame
        JFrame frame = new JFrame("Company Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Setting the size of the page
        frame.setSize(1000, 800);
        frame.setLocationRelativeTo(null);
        // Adding some space between panels
        frame.setLayout(new BorderLayout(10, 10));
        frame.setVisible(true);

        // Creating a JPanel for the company title, overview, and go-back button
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setPreferredSize(new Dimension(100, 100));
        topPanel.setBackground(Color.lightGray);

        // Creating a JLabel that shows the company's name
        JLabel titleOfCompany = new JLabel();
        titleOfCompany.setText("Company Name Information Page"); // The selected company's name goes here
        titleOfCompany.setBackground(Color.lightGray);

        // Changing title font and size
        Font titleFont = new Font("Times New Roman", Font.BOLD, 40);
        titleOfCompany.setFont(titleFont);

        // Changing title position
        titleOfCompany.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleOfCompany.setAlignmentY(Component.TOP_ALIGNMENT);

        // Adding the title to the panel
        topPanel.add(titleOfCompany, BorderLayout.NORTH);

        // Creating a text area for the company overview
        JLabel companyOverview = new JLabel("Company Info & Rank Go Here"); // Company's overview goes here

        // Setting font and size
        Font overviewFont = new Font("Times New Roman", Font.PLAIN, 14);
        companyOverview.setFont(overviewFont);

        // Aligning
        companyOverview.setAlignmentX(Component.LEFT_ALIGNMENT);
        companyOverview.setAlignmentY(Component.CENTER_ALIGNMENT);

        // Adding the JTextArea to the JPanel
        topPanel.add(companyOverview, BorderLayout.CENTER);

        // Creating a button to go back to the previous page
        JButton goBackButton = new JButton("Go Back");

        // Size adjustment
        goBackButton.setPreferredSize(new Dimension(90, 20));

        // Alignment
        goBackButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Adding the button to the panel
        topPanel.add(goBackButton, BorderLayout.EAST);

        // Adding a listener that does something when the user presses on a button
        // In this case: goes to the previous page (welcome page) when button is pressed
        goBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Calling the createWelcomePageGUI method from StartingPage.java, which creates the page again
                StartingPage.createAndShowGUI(null, null); // TODO: fix this

                // Setting this page (companyPage) to not-visible so the user automatically sees the previous page
                frame.setVisible(false);
                /*
                 * Disposing of the page: basically gets rid of the components of this page
                 * Frees up memory
                 */
                frame.dispose();
            }
        });

        // Creating a JPanel for the company's data
        JPanel resultsPanel = new JPanel();
        resultsPanel.setPreferredSize(new Dimension(100, 100));
        resultsPanel.setBackground(Color.WHITE);
        // @author ChatGPT - changed the layout of the panel to fix an issue with positioning
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));
        // Yazan
        // Creating JLabels that provide the user with company data
        JLabel wageDisparity = new JLabel("data on wage disparity goes here");
        JLabel employeeMaleToFemaleRatio = new JLabel("data on male to female employees ratio goes here");
        JLabel reportedIncidents = new JLabel("data on reported incidents goes here");
        JLabel employeeDiversity = new JLabel("data on employee diversity by demographic goes here");
        JLabel companyScore = new JLabel("data on the company's score goes here");
        resultsPanel.add(wageDisparity);
        resultsPanel.add(employeeMaleToFemaleRatio);
        resultsPanel.add(reportedIncidents);
        resultsPanel.add(employeeDiversity);
        resultsPanel.add(companyScore);

        // Creating a JPanel that shows the company rankings (based off region)
        JPanel companiesPanel = new JPanel(null);
        companiesPanel.setPreferredSize(new Dimension(400,600));
        resultsPanel.add(companiesPanel);
        JScrollPane scrollableList = new JScrollPane(companiesPanel);
        scrollableList.setBounds(100, 600, 300, 400);
        resultsPanel.add(scrollableList);




        // adding the panels to the frame
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(resultsPanel, BorderLayout.CENTER);
        frame.add(companiesPanel);
    }
}