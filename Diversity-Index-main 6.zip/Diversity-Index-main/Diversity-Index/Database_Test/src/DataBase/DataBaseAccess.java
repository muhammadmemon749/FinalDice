package DataBase;

/**
 * This class represents a record in the CompanyDetails table.
 * 
 * @author Muhammad Ahmed Memon
 */
public class DataBaseAccess {
    private String companyName;
    private String companyOverview;
    private int percentOfMinoritiesHired;
    private int percentFemalesHired;
    private int percentMalesHired;
    private int workplaceSafetyScore;

    /**
     * Constructs a new DatabaseAccess object with the specified details.
     * 
     * @param companyName the name of the company
     * @param companyOverview a brief overview of the company
     * @param percentOfMinoritiesHired the percentage of minorities hired by the company
     * @param percentFemalesHired the percentage of females hired by the company
     * @param percentMalesHired the percentage of males hired by the company
     * @param workplaceSafetyScore the workplace safety score of the company
     */
    public DataBaseAccess(String companyName, String companyOverview, int percentOfMinoritiesHired, int percentFemalesHired, int percentMalesHired, int workplaceSafetyScore) {
        this.companyName = companyName;
        this.companyOverview = companyOverview;
        this.percentOfMinoritiesHired = percentOfMinoritiesHired;
        this.percentFemalesHired = percentFemalesHired;
        this.percentMalesHired = percentMalesHired;
        this.workplaceSafetyScore = workplaceSafetyScore;
    }

    // Getters and Setters
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyOverview() {
        return companyOverview;
    }

    public void setCompanyOverview(String companyOverview) {
        this.companyOverview = companyOverview;
    }

    public int getPercentOfMinoritiesHired() {
        return percentOfMinoritiesHired;
    }

    public void setPercentOfMinoritiesHired(int percentOfMinoritiesHired) {
        this.percentOfMinoritiesHired = percentOfMinoritiesHired;
    }

    public int getPercentFemalesHired() {
        return percentFemalesHired;
    }

    public void setPercentFemalesHired(int percentFemalesHired) {
        this.percentFemalesHired = percentFemalesHired;
    }

    public int getPercentMalesHired() {
        return percentMalesHired;
    }

    public void setPercentMalesHired(int percentMalesHired) {
        this.percentMalesHired = percentMalesHired;
    }

    public int getWorkplaceSafetyScore() {
        return workplaceSafetyScore;
    }

    public void setWorkplaceSafetyScore(int workplaceSafetyScore) {
        this.workplaceSafetyScore = workplaceSafetyScore;
    }

}
