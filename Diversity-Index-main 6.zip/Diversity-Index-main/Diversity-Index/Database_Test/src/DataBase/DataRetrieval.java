package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Class that retrevies tha data from the database table.
 * 
 * @author Muhammad Ahmed Memon
 */
public class DataRetrieval {
    private Connection con;


    /**
     * Initializes a new instance of DataRetrieval with the given database connection.
     * 
     * @param con the database connection to be used for table management.
     */
    public DataRetrieval(Connection con) {
        this.con = con;
    }

    /**
     * Retrieves all company details from the database.
     * 
     * @return A list of CompanyDetails objects.
     * @throws SQLException if a database access error occurs or the SQL statement is not valid.
     * 
     * tutorial for while loop: https://www.baeldung.com/jdbc-resultset 
     * Examples for try and catch block: https://docs.oracle.com/javase/8/docs/technotes/guides/jdbc/jdbc_41.html & https://learn.microsoft.com/en-us/sql/connect/jdbc/managing-result-sets-with-the-jdbc-driver?view=sql-server-ver16 
     */
    public List<DataBaseAccess> getCompanyDetails() throws SQLException {
        List<DataBaseAccess> companyList = new ArrayList<>();
        String query = "SELECT * FROM CompanyDetails";

        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                String companyName = rs.getString("company_name");
                String companyOverview = rs.getString("company_overview");
                int percentOfMinoritiesHired = rs.getInt("percent_of_minorities_hired");
                int percentFemalesHired = rs.getInt("percent_females_hired");
                int percentMalesHired = rs.getInt("percent_males_hired");
                int workplaceSafetyScore = rs.getInt("workplace_safety_score");

                DataBaseAccess companyDetails = new DataBaseAccess(companyName, companyOverview, percentOfMinoritiesHired, percentFemalesHired, percentMalesHired, workplaceSafetyScore);
                companyList.add(companyDetails);
            }
        }

        return companyList;
    }
}
