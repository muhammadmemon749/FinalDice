/**
 * Diversity Comparator implements the Comparator interface and can compare DatabaseAccess objects based on how many minorities they hire.
 * @author Faith Tong
 */

package Comparators;

import java.util.Comparator;
import java.lang.Math;
import DataBase.DatabaseAccess;

public class DiversityComparator implements Comparator<DatabaseAccess>{
    /**
     * Compares companies by seeing how close to 30% minorities a company hires.
     * @param d1 DatabaseAccess object which is being compared to another company.
     * @param d2 The second DatabaseAccess object being compared.
     * @return Returns an integer. -1 if d1 comes before d2, 0 if they are the same, 1 if d1 comes after d2.
     */
    public int compare(DatabaseAccess d1, DatabaseAccess d2) {
        double d1Difference = Math.abs(30 - d1.getPercentOfMinoritiesHired());
        double d2Difference = Math.abs(30 - d2.getPercentOfMinoritiesHired());

        if (d1Difference < d2Difference) {
            return -1;
        }
        else if (d1Difference == d2Difference) {
            return 0;
        }
        else {
            return 1;
        }
    }
}
