/**
 * OverallComparator implements the Comparator interface and can compare DatabaseAccess objects by combining all other rankings to get a total score.
 * @author Faith Tong
 */

package Comparators;

import java.util.Comparator;
import java.util.ArrayList;
import DataBase.DatabaseAccess;

public class OverallComparator implements Comparator<DatabaseAccess>{
    ArrayList<DatabaseAccess> genderRanking;
    ArrayList<DatabaseAccess> diversityRanking;
    ArrayList<DatabaseAccess> safetyRanking;

    /**
     * The construtor takes ArrayLists with rankings that need to be saved in the OverallComparator object's fields.
     * @param g ArrayList<DatabaseAccess> with the ranking based on gender treatment.
     * @param d ArrayList<DatabaseAccess> with the ranking of how diverse the hires are.
     * @param s ArrayList<DatabaseAccess> with the ranking of how many safety incidents there were.
     */
    public OverallComparator(ArrayList<DatabaseAccess> g, ArrayList<DatabaseAccess> d, ArrayList<DatabaseAccess> s) {
        genderRanking = g;
        diversityRanking = d;
        safetyRanking = s;
    }

    /**
     * Compares companies by seeing how well they are ranked in all other categories.
     * @param d1 DatabaseAccess object which is being compared to another company.
     * @param d2 The second DatabaseAccess object being compared.
     * @return Returns an integer. -1 if d1 comes before d2, 0 if they are the same, 1 if d1 comes after d2.
     */
    public int compare(DatabaseAccess d1, DatabaseAccess d2) {
        int d1Score = genderRanking.indexOf(d1) + diversityRanking.indexOf(d1) + safetyRanking.indexOf(d1);
        int d2Score = genderRanking.indexOf(d2) + diversityRanking.indexOf(d2) + safetyRanking.indexOf(d2);

        if(d1Score < d2Score) {
            return -1;
        }
        else if (d1Score == d2Score) {
            return 0;
        }
        else {
            return 1;
        }

    }
}
