/**
 * SafetyComparator implements the Comparator interface and can compare DatabaseAccess objects based on how many safety incidents occurred.
 * @author Faith Tong
 */

package Comparators;

import java.util.Comparator;
import DataBase.DatabaseAccess;

public class SafetyComparator implements Comparator<DatabaseAccess> {
    /**
     * Compares companies by seeing how many safety incidents were reported - the lower the better.
     * @param d1 DatabaseAccess object which is being compared to another company.
     * @param d2 The second DatabaseAccess object being compared.
     * @return Returns an integer. -1 if d1 comes before d2, 0 if they are the same, 1 if d1 comes after d2.
     */
    public int compare(DatabaseAccess d1, DatabaseAccess d2) {
        if (d1.getWorkplaceSafetyScore() < d2.getWorkplaceSafetyScore()) {
            return -1;
        }
        else if (d1.getWorkplaceSafetyScore() == d2.getWorkplaceSafetyScore()) {
            return 0;
        }
        else {
            return 1;
        }
    }
}
