package DataBase;

import java.sql.*;
import java.io.*;
import java.util.Scanner;

/**
 * Manages the 'CompanyDetails' table in the database.
 * This class includes methods to create and modify the 'CompanyDetails' table.
 * It requires an established database connection to function.
 * 
 * @author Muhammad Ahmed Memon
 */
public class CompanyTableManager {
    private Connection con;

    /**
     * Initializes a new instance of CompanyTableManager with the given database connection.
     * 
     * @param con the database connection to be used for table management.
     */
    public CompanyTableManager(Connection con) {
        this.con = con;
    }

     /**
     * Creates the 'CompanyDetails' table in the database if it does not exist.
     * The table includes columns for company name, company overview, and various employment statistics.
     * 
     * @throws SQLException if there is an error executing the table creation statement in the database.
     */
    public void createTable() throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS CompanyDetails (" + "company_name VARCHAR(255), " + "company_overview VARCHAR(255), " + "percent_of_minorities_hired INT, " + "percent_females_hired INT, " + "percent_males_hired INT, " + "workplace_safety_score INT)";
        Statement stmt = con.createStatement();
        stmt.executeUpdate(createTableSQL);
        System.out.println("Table 'CompanyDetails' is created successfully.");
        stmt.close();
    }

    /**
     * Inserts data into the 'CompanyDetails' table from a text file.
     * 
     * @param filePath the path of the file containing the data to be inserted.
     * @throws SQLException if there is an error executing the insert statements in the database.
     * @throws FileNotFoundException if the specified file is not found.
     */
    public void insertDataFromFile(String filePath) throws SQLException, FileNotFoundException {
        File file = new File(filePath);
        Scanner scanner = new Scanner(file);
        PreparedStatement pstmt = con.prepareStatement(
            "INSERT INTO CompanyDetails (company_name, company_overview, percent_of_minorities_hired, " +
            "percent_females_hired, percent_males_hired, workplace_safety_score) VALUES (?, ?, ?, ?, ?, ?)");

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] values = line.split(", ");

            for (int i = 0; i < values.length; i++) {
                pstmt.setString(i + 1, values[i].trim());
            }

            pstmt.executeUpdate();
        }

        System.out.println("Data from file inserted successfully.");
        scanner.close();
        pstmt.close();
    }
}
