package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages the database connection to a MySQL database.
 * 
 * @author Muhammad Ahmed Memon
 */

public class DataBaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/my_new_database";
    private static final String USER = "root";
    private static final String PASSWORD = "DICEDICE";

    /**
     * Establishes and returns a connection to the database.
     * 
     * @return A Connection object representing the database connection.
     * @throws SQLException if there is an error establishing the database connection.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
