package App;

import java.util.ArrayList;
import javax.swing.*;
import GUI.*;
import DataBase.*;
import java.util.List;
import java.sql.Connection;

/**
 * This class initializes the database connection, manages the company table, retrieves data for ranking, and initializes the GUI components.
 * 
 * Credit is given to different contributors for specific parts of the code as indicated.
 */
public class Main {

    /**
     * @author Muhammad Ahmed Memon
     */
    public static void main(String[] args) {

        List<DatabaseAccess> retrieved = null;
        try {
            Connection con = DataBaseConnection.getConnection();

            CompanyTableManager tableManager = new CompanyTableManager(con);
            tableManager.createTable();
            tableManager.insertDataFromFile("/Users/muhammadmemon/Downloads/companies_data.txt");

            DataRetrieval dataRetrieval = new DataRetrieval(con);
            retrieved = dataRetrieval.getCompanyDetails();

        } catch (Exception e) {
            e.printStackTrace();
        }
    
        /**
        * @author Faith
        */
        if (retrieved != null) {
            ArrayList<DatabaseAccess> companies = new ArrayList<>();
            companies.addAll(retrieved);
            Ranker ranker = new Ranker(companies);
            ranker.rankCompanies();

            /**
            * @author Yazan
            */
            SwingUtilities.invokeLater(() -> CompanyPage.createFrame());
            SwingUtilities.invokeLater(() -> CompanyPage.createRankingGUI());
            SwingUtilities.invokeLater(() -> StartingPage.createAndShowGUI(companies, ranker));
        }
    }
}
